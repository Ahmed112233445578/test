new kursor({
    type: 3,
    removeDefaultCursor: true,
    color: "#f3703c"
});